package com.company.common;

public interface StringProcessingService {
	String processString(String str);
}
