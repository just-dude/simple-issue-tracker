package com.company.annotationdemo;

public interface StringProcessingService {
	String processString(String str);
}
